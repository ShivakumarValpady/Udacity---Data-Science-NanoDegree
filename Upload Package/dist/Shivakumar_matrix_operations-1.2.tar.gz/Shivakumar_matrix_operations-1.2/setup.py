from setuptools import setup

setup(name = 'Shivakumar_matrix_operations',
      version = '1.2',
      description = 'Basic Matrix Operations',
      packages = ['Shivakumar_matrix_operations'],
      author = 'Shivakumar Valpady',
      zip_safe = False,
      install_requires = ['numpy']      
      )
